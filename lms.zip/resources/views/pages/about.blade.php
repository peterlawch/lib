@extends('main')

@section('title', '| About')

@section('content')
        <div class="row">
            <div class="col-md-12">
                <h1>About Me</h1>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consequuntur possimus minima tempore amet temporibus ipsum reprehenderit repudiandae magnam. Iusto numquam molestias saepe maxime, accusamus cupiditate sequi impedit animi blanditiis quasi.</p>
            </div>
        </div>
@endsection

