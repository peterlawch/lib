<nav class="navbar has-shadow" >
  <div class="container">
    <div class="navbar-brand">
      <a class="navbar-item is-paddingless brand-item" href="<?php echo e(route('home')); ?>">
        <img src="<?php echo e(asset('images/library-logo2.png')); ?>" alt="SCMC Library Logo">
      </a>

      <?php if(Request::segment(1) == "manage"): ?>
        <a class="navbar-item is-hidden-desktop" id="admin-slideout-button">
          <span class="icon">
            <i class="fa fa-arrow-circle-right"></i>
          </span>
        </a>
      <?php endif; ?>

      <button class="button navbar-burger">
       <span></span>
       <span></span>
       <span></span>
     </button>
    </div>
    <div class="navbar-menu">
      <div class="navbar-start">
        <a href="<?php echo e(route('login')); ?>" class="navbar-item is-tab is-active">Home</a>
        <a class="navbar-item is-tab">About Us</a>
        <a class="navbar-item is-tab">Contact</a>
      </div> <!-- end of .navbar-start -->


      <div class="navbar-end nav-menu" style="overflow: visible">
        <?php if(auth()->guard()->guest()): ?>
          <a href="<?php echo e(route('login')); ?>" class="navbar-item is-tab">Login</a>
          <a href="<?php echo e(route('register')); ?>" class="navbar-item is-tab">Join as Member</a>
        <?php else: ?>   
          <div class="navbar-item has-dropdown is-hoverable">
            <a class="navbar-link">Hey <?php echo e(Auth::user()->name); ?></a>
            <div class="navbar-dropdown is-right" >
              <a href="#" class="navbar-item">
                <span class="icon">
                  <i class="fa fa-fw fa-user-circle-o m-r-5"></i>
                </span>Profile
              </a>

              <a href="#" class="navbar-item">
                <span class="icon">
                  <i class="fa fa-fw fa-bell m-r-5"></i>
                </span>Notifications
              </a>
              <a href="<?php echo e(route('manage.dashboard')); ?>" class="navbar-item">
                <span class="icon">
                  <i class="fa fa-fw fa-cog m-r-5"></i>
                </span>Manage
              </a>
              <a href="<?php echo e(route('categories.index')); ?>" class="navbar-item">
                <span class="icon">
                  <i class="fa fa-fw fa-cog m-r-5"></i>
                </span>Categories
              </a>
              <a href="<?php echo e(route('tags.index')); ?>" class="navbar-item">
                <span class="icon">
                  <i class="fa fa-fw fa-cog m-r-5"></i>
                </span>Tags
              </a>
              <hr class="navbar-divider">
              <a href="<?php echo e(route('logout')); ?>" class="navbar-item" onclick="event.preventDefault();
                         document.getElementById('logout-form').submit();">
                <span class="icon">
                  <i class="fa fa-fw fa-sign-out m-r-5"></i>
                </span>
                Logout
              </a>
              <?php echo $__env->make('_includes.forms.logout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>

  </div>
</nav>