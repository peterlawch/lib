<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="columns">
            <div class="column">
                <h1 class="title">Manage Users</h1>
            </div>
            <div class="column">
                <a href="<?php echo e(route('users.create')); ?>" class="button is-primary"><i class="fa fa-user-add m-r-10"></i>Create New User</a>
            </div>
        </div>
    </div>
<?php echo $__env->make('layouts.manage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>