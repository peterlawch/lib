<?php $__env->startSection('title', '| $post->title'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8 col-md-offset-2 m-t-50">
            <h1 class="title"><?php echo e($post->title); ?></h1>
            <p><?php echo e($post->body); ?></p>
            <hr>
            <p>Posted In: <?php echo e($post->category->name); ?></p>
        </div>
        <div class="visible-print text-center m-t-50" id="printableArea" >
        <img src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')->size(100)->encoding('UTF-8')->generate("http://192.168.0.111/book/695/facebook")); ?>">
            <p><?php echo e($post->title); ?></p>
            <span class="pull-right"><button class="btn btn-default btn-print" type="button"
                onclick="printDiv('printableArea')">
            <i class="fa fa-print"></i> Print</button></span>
        </div>
    </div>
    <script type="text/javascript">
        function printDiv ( divName ) {
            var printContents       = document.getElementById(divName).innerHTML;
            var originalContents    = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>