<div class="side-menu" id="admin-side-menu">
  <aside class="menu m-t-20 m-l-20">
    <p class="menu-label">
      General
    </p>
    <ul class="menu-list">
      <li><a href="<?php echo e(route('manage.dashboard')); ?>" class="<?php echo e(Nav::isRoute('manage.dashboard')); ?>">Dashboard</a></li>
    </ul>

    <p class="menu-label">
      Content
    </p>
    <ul class="menu-list">
      <li><a href="<?php echo e(route('posts.index')); ?>" class="<?php echo e(Nav::isResource('posts', 2)); ?>">Managing Books</a></li>
      
    </ul>

    <p class="menu-label">
      Administration
    </p>
    <ul class="menu-list">
      <li><a href="<?php echo e(route('users.index')); ?>" class="<?php echo e(Nav::isResource('users')); ?>">Manage Users</a></li>
      <li>
        <a class="has-submenu <?php echo e(Nav::hasSegment(['roles', 'permissions'], 2)); ?>">Roles &amp; Permissions</a>
        <ul class="submenu">
          <li><a href="<?php echo e(route('roles.index')); ?>" class="<?php echo e(Nav::isResource('roles')); ?>">Roles</a></li>
          <li><a href="<?php echo e(route('permissions.index')); ?>" class="<?php echo e(Nav::isResource('permissions')); ?>">Permissions</a></li>
        </ul>
      </li>
      <li>
        <a class="has-submenu">Example Accordion</a>
        <ul class="submenu">
          <li><a href="<?php echo e(route('roles.index')); ?>">Roles</a></li>
          <li><a href="<?php echo e(route('permissions.index')); ?>">Permissions</a></li>
        </ul>
      </li>
      <li>
        <a class="has-submenu">Another Example</a>
        <ul class="submenu">
          <li><a href="<?php echo e(route('roles.index')); ?>">Roles</a></li>
          <li><a href="<?php echo e(route('permissions.index')); ?>">Permissions</a></li>
        </ul>
      </li>
    </ul>
  </aside>
</div>