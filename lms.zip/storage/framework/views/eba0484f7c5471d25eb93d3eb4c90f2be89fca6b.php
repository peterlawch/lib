<?php $__env->startSection('title', '| About'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-12">
                <h1>About Me</h1>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consequuntur possimus minima tempore amet temporibus ipsum reprehenderit repudiandae magnam. Iusto numquam molestias saepe maxime, accusamus cupiditate sequi impedit animi blanditiis quasi.</p>
            </div>
        </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>